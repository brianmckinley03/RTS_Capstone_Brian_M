/*
 * ============================================================================
 *  CAPSTONE — "Bed 4-A" Integrated ECG Bedside Monitor
 *  EEE 4775 Real-Time Systems — Capstone Project
 *  Author: Brian McKinley
 *  Platform: ESP32-S3 (esp32s3-devkitc-1), ESP-IDF v5.x, Wokwi simulator
 * ============================================================================
 *
 *  This file merges the five semester assignments into one running system
 *  with the SAME theme ("Bed 4-A") that ran through all five:
 *
 *    App 1  -> Dual-core architecture + HTTP web dashboard          (task_web_monitor)
 *    App 2  -> The periodic task set & its rate-monotonic schedule  (ecg/detect/dispatch/log)
 *    App 3  -> ISR top-half / bottom-half pattern + latency proof   (stat_button_isr -> task_alarm)
 *    App 4  -> Mutex / counting semaphore / binary semaphore,       (record_mutex, sample_backlog_sem,
 *              induced-failure and priority-inversion demonstrations  stat_alarm_sem, demo toggles)
 *    App 5  -> Queue + event group + task notification IPC          (alarm_evt_q, cycle_evt_group,
 *              producer/consumer pipeline                            coordinator/responder pattern)
 *
 *  NEW for the capstone (not present in any single assignment):
 *    - A graceful-degradation ladder (system_mode_t) driven by a dedicated
 *      degradation-manager task that watches overrun/backlog/deadline-miss
 *      counters and a heartbeat watchdog, and sheds non-essential work in a
 *      fixed order while the vitals-capture / detection / alarm path is
 *      NEVER shed. See README.md "Graceful Degradation" for the full design
 *      rationale — the short version is in the comment above system_mode_t.
 *    - Per-task WCET instrumentation (execution time, not just latency) and
 *      an explicit deadline-miss counter per periodic task, used in
 *      README.md's schedule / worst-case-timing analysis.
 *    - A visible, physically-distinct FAULT annunciator (yellow LED) that is
 *      intentionally separate from the patient ALARM annunciator (red LED),
 *      because conflating "the system is unwell" with "the patient is
 *      unwell" is itself a hazard — see README.md hazard analysis, H-06.
 *
 *  AI disclosure: this integration (task-set merge, degradation-manager
 *  design, WCET/deadline instrumentation, and this file's structure) was
 *  drafted with AI assistance from Claude (Anthropic), starting from Brian
 *  McKinley's own five graded submissions as the source material. Every
 *  primitive, task body, and comment inherited from a prior app is marked
 *  with the app it came from above and in-line below. Full disclosure and
 *  prompt history are in README.md Section 8.
 *
 *  IMPORTANT — scope honesty: this is a coursework simulation on a Wokwi
 *  ESP32-S3, not a certified medical device. "IEC 62304" is invoked here
 *  only in spirit (safety classification thinking, hazard-driven design,
 *  documented verification) — see README.md Section 7. No real patient
 *  should ever be connected to this.
 * ============================================================================
 */

/* ---------------------------------------------------------------------------
 * Compile-time demo / diagnostic switches.
 * ALL DEFAULT TO 0 — the default build is the safe, production-shaped one.
 * Each switch reproduces a specific graded experiment from A3/A4 so the
 * evidence those assignments generated is still reproducible from this one
 * codebase. See README.md Section 6 for what each one demonstrates and why
 * it is safe to leave permanently compiled-in but defaulted off.
 * ------------------------------------------------------------------------- */
#ifndef USE_WEBSERVER
#define USE_WEBSERVER 1          /* App 1: 0 = serial-only fallback (Wi-Fi/gateway flaky in Wokwi) */
#endif
#ifndef BREAK_ISR_SAFETY_RULE
#define BREAK_ISR_SAFETY_RULE 0  /* App 3: 1 = drop portYIELD_FROM_ISR, exposes deferred-preemption latency */
#endif
#ifndef INDUCE_FAILURE
#define INDUCE_FAILURE 0         /* App 4: 1 = remove the mutex around patient_record, exposes a torn read */
#endif
#ifndef PRIORITY_INVERSION_DEMO
#define PRIORITY_INVERSION_DEMO 0 /* App 4: 1 = run the isolated H/M/L inversion demo alongside the system */
#endif
#ifndef OVERLOAD_DEMO
#define OVERLOAD_DEMO 0          /* NEW: 1 = saturate Core 1 to force the degradation ladder to step down live */
#endif

#define LOCK_MUTEX  0
#define LOCK_BINARY 1
#ifndef LOCK_TYPE
#define LOCK_TYPE LOCK_MUTEX      /* MUTEX = priority inheritance ON, BINARY = priority inheritance OFF */
#endif

#include <stdio.h>
#include <string.h>
#include <math.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "freertos/queue.h"
#include "freertos/event_groups.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "esp_attr.h"

#if USE_WEBSERVER
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_http_server.h"
#include "esp_netif.h"
#include "nvs_flash.h"
#endif

static const char *TAG = "bed4a_capstone";

/* ============================================================================
 * Pin map (see diagram.json). Alarm/vitals/STAT reuse the exact GPIOs A1/A4
 * used, for continuity with the grader's expectations; two GPIOs are new.
 * ============================================================================
 *   GPIO 2   LED_ALARM_GPIO    red    — patient alarm annunciator   (App 1/4 pin, NEVER shed)
 *   GPIO 15  LED_VITALS_GPIO   green  — ~1 Hz proof-of-life beacon  (new — derived from hb_ecg)
 *   GPIO 16  LED_FAULT_GPIO    yellow — SYSTEM fault/degraded light (new — see H-06 below)
 *   GPIO 4   BTN_STAT_GPIO     —      — clinician "STAT" button     (App 4 pin)
 *   GPIO 18  BTN_SIM_GPIO      —      — inject a simulated abnormal-rhythm burst (test aid)
 *   GPIO 19  SCOPE_ISR_GPIO    —      — logic-analyzer probe around the STAT ISR (App 3 pin)
 * ============================================================================ */
#define LED_ALARM_GPIO   GPIO_NUM_2
#define LED_VITALS_GPIO  GPIO_NUM_15
#define LED_FAULT_GPIO   GPIO_NUM_16
#define BTN_STAT_GPIO    GPIO_NUM_4
#define BTN_SIM_GPIO     GPIO_NUM_18
#define SCOPE_ISR_GPIO   GPIO_NUM_19

#define DEBOUNCE_US 200

/* ============================================================================
 * Graceful degradation ladder
 * ============================================================================
 * NORMAL        -> everything runs.
 * DEGRADED_1    -> shed alarm telemetry/dispatch (task_alarm_dispatch) and the
 *                  event-group cycle-latency instrumentation (task_coordinator).
 *                  Neither affects the patient-facing alarm output.
 * DEGRADED_2    -> also shed housekeeping/logging (task_data_log). Web
 *                  dashboard keeps running but stops getting fresh history.
 * SAFE_MINIMAL  -> only ECG sampling, arrhythmia detection, and the alarm
 *                  ISR/task survive. FAULT LED is latched on. This state is
 *                  entered IMMEDIATELY (no hysteresis) on the two conditions
 *                  that indicate the vitals or alarm path itself may be
 *                  compromised (ECG heartbeat watchdog stall, or a mutex
 *                  take that timed out) — see H-01/H-02 in the hazard table.
 *                  A degraded monitor that LOOKS normal is worse than one
 *                  that visibly says it is degraded; SAFE_MINIMAL always
 *                  makes that visible via LED_FAULT and the web banner.
 *
 * Escalation (stepping down into worse modes) uses SHORT hysteresis — a
 * few consecutive bad 100 ms checks. Recovery (stepping back up) uses LONG
 * hysteresis — many consecutive clean checks. This asymmetry is deliberate:
 * fail fast, recover cautiously. It is standard alarm-management practice,
 * not just an RTOS habit — see README.md hazard H-05.
 * ============================================================================ */
typedef enum {
    MODE_NORMAL = 0,
    MODE_DEGRADED_1,
    MODE_DEGRADED_2,
    MODE_SAFE_MINIMAL,
} system_mode_t;

static volatile system_mode_t system_mode = MODE_NORMAL;
static volatile uint32_t mode_transition_count = 0;
static volatile uint32_t mutex_timeout_count = 0;     /* contention/inversion proxy, feeds degradation */
static volatile uint32_t coordinator_timeout_count = 0;

static const char *mode_name(system_mode_t m) {
    switch (m) {
        case MODE_NORMAL:       return "NORMAL";
        case MODE_DEGRADED_1:   return "DEGRADED_1";
        case MODE_DEGRADED_2:   return "DEGRADED_2";
        case MODE_SAFE_MINIMAL: return "SAFE_MINIMAL";
        default:                return "?";
    }
}

/* ============================================================================
 * Shared resource #1: patient_record_t — protected by a MUTEX.        [App 4]
 * ============================================================================
 * Multi-field struct written by task_arrhy_detect and task_alarm_isr, read
 * by task_data_log and task_web_monitor. A bare bool would be atomic on
 * Xtensa (single aligned byte); this struct is not, so an unserialized
 * reader can catch it mid-update (torn read) — that's exactly what
 * INDUCE_FAILURE=1 exposes on purpose.
 * ============================================================================ */
typedef struct {
    int32_t       heart_rate_bpm;
    bool          arrhythmia_flag;
    uint32_t      alarm_count;
    bool          alarm_active;
    system_mode_t mode;
} patient_record_t;

static patient_record_t patient_record;
static SemaphoreHandle_t record_mutex;

/* ============================================================================
 * Shared resource #2: ECG ring buffer + COUNTING SEMAPHORE (backlog).  [App 4]
 * ============================================================================
 * task_ecg_sample (producer, 10 ms, hard periodic) drops a sample in the
 * ring and gives sample_backlog_sem. task_arrhy_detect (consumer, 20 ms
 * periodic) drains everything pending each cycle. Depth 8 = ~2x the 20/10 ms
 * rate ratio: enough slack to absorb one detector stall without silently
 * dropping data, small enough that a stuck detector is visible fast.
 * ============================================================================ */
#define ECG_RING_DEPTH 8
static volatile int32_t  ecg_ring[ECG_RING_DEPTH];
static volatile uint32_t ecg_ring_head = 0;
static volatile uint32_t ecg_ring_tail = 0;
static SemaphoreHandle_t sample_backlog_sem;
static volatile uint32_t ecg_overrun_count = 0;

/* ============================================================================
 * Shared resource #3: alarm telemetry QUEUE.                          [App 5]
 * ============================================================================
 * task_alarm_isr (the fast, never-shed path) pushes a lightweight alarm_event_t
 * for every alarm it services. task_alarm_dispatch (40 ms, SHEDDABLE) drains
 * this queue and does the "heavy" formatting/telemetry work. This queue is
 * the deliberate seam between "must always work" and "nice to have": if the
 * queue fills, telemetry is dropped and counted — the physical alarm LED and
 * patient_record update already happened upstream, unaffected.
 * ============================================================================ */
typedef struct {
    uint32_t t_ms;
    uint8_t  source;    /* 0 = STAT button, 1 = software-detected arrhythmia */
    uint32_t alarm_no;
} alarm_event_t;

#define ALARM_Q_DEPTH 8
static QueueHandle_t alarm_evt_q;
static volatile uint32_t alarm_dispatch_drops = 0;

/* ============================================================================
 * Shared resource #4: STAT alarm signal — BINARY SEMAPHORE.           [App 4]
 * ============================================================================
 * Given from the STAT button ISR (hardware path) OR from task_arrhy_detect
 * (software-detected-anomaly path). Either source wakes the SAME highest-
 * priority task, because Bed 4-A has exactly one alarm output and it must
 * not matter which source tripped it.
 * ============================================================================ */
static SemaphoreHandle_t stat_alarm_sem;
static volatile uint32_t isr_fire_count = 0;
static volatile uint32_t sw_trigger_count = 0;
static volatile int64_t  alarm_trigger_time_us = 0;
static volatile uint64_t alarm_latency_max_us = 0;

/* ============================================================================
 * Shared resource #4b: direct TASK NOTIFICATION — the same STAT ISR that
 * gives stat_alarm_sem above also notifies task_ui_notify directly.     [App 5]
 * ============================================================================
 * This is deliberately the same ISR feeding two different bottom-halves,
 * reproducing App 3's semaphore-vs-notification latency comparison inside
 * the merged system: stat_alarm_sem drives the safety-critical alarm path
 * (prio 20), the notification drives a cheap, sheddable "UI just refreshed"
 * timestamp (prio 13) with its own latency measurement. The two paths are
 * NOT at equal priority the way App 3's isolated experiment had them —
 * here the safety path is intentionally favored, and that priority gap is
 * itself part of what README.md's WCET section explains.
 * ============================================================================ */
static TaskHandle_t ui_notify_handle;
static volatile uint64_t notif_latency_max_us = 0;
static volatile uint32_t last_stat_ui_refresh_ms = 0;
static volatile uint32_t hb_ui = 0;

/* ============================================================================
 * Shared resource #5: cycle-rendezvous EVENT GROUP.                   [App 5]
 * ============================================================================
 * task_coordinator waits for BOTH "a sample was produced" and "a detect
 * cycle ran" before counting a completed pipeline "beat" — purely an
 * observability/latency-evidence primitive (README WCET section), so it is
 * one of the first things shed under load (DEGRADED_1).
 * ============================================================================ */
#define EV_SAMPLE_READY  (1 << 0)
#define EV_DETECT_DONE   (1 << 1)
static EventGroupHandle_t cycle_evt_group;

/* Debounce state, shared between the two button ISRs' own static locals. */
static volatile int64_t last_stat_edge_us = 0;
static volatile int64_t last_sim_edge_us  = 0;

/* Anomaly-injection window set by the SIM button, consumed by task_ecg_sample. */
static volatile int64_t anomaly_inject_until_us = 0;

/* Heartbeats — proof of life + watchdog input. Single 32-bit reads/writes
 * are atomic on Xtensa, so these are read without a lock (same rationale
 * App 1/5 already used for their heartbeat counters). */
static volatile uint32_t hb_ecg = 0, hb_arrhy = 0, hb_dispatch = 0,
                          hb_degr = 0, hb_log = 0, hb_alarm = 0, hb_coord = 0;

/* Per-task WCET (execution time, not latency) + deadline-miss counters.
 * Fed into README.md's schedule / worst-case-timing table after a Wokwi run —
 * see the MEASURE_WCET macro below and README Section 4. */
static volatile uint64_t wcet_ecg_us = 0, wcet_arrhy_us = 0,
                          wcet_dispatch_us = 0, wcet_log_us = 0;
static volatile uint32_t deadline_miss_ecg = 0, deadline_miss_arrhy = 0,
                          deadline_miss_dispatch = 0, deadline_miss_log = 0;

#define MEASURE_WCET(_dt_var, _max_var, _body) do {              \
    int64_t _t0 = esp_timer_get_time();                          \
    _body;                                                        \
    (_dt_var) = esp_timer_get_time() - _t0;                      \
    if ((uint64_t)(_dt_var) > (_max_var)) (_max_var) = (uint64_t)(_dt_var); \
} while (0)

static inline void note_deadline(int64_t dt_us, uint32_t period_ms, volatile uint32_t *miss_ctr)
{
    if (dt_us > (int64_t)period_ms * 1000) {
        (*miss_ctr)++;
        ESP_LOGW(TAG, "DEADLINE MISS: exec %lld us > period %lu ms", (long long)dt_us, (unsigned long)period_ms);
    }
}

/* Mutex take with a bounded timeout + contention counter. Used everywhere
 * patient_record is touched outside the INDUCE_FAILURE path, so a stuck
 * lock (real deadlock, or a starved low-priority holder) is COUNTED and fed
 * to the degradation manager instead of silently hanging a task forever. */
static inline bool record_lock(TickType_t timeout)
{
    if (xSemaphoreTake(record_mutex, timeout) == pdTRUE) return true;
    mutex_timeout_count++;
    ESP_LOGE(TAG, "record_mutex TIMEOUT (contention count=%lu)", (unsigned long)mutex_timeout_count);
    return false;
}
#define record_unlock() xSemaphoreGive(record_mutex)

/* ============================================================================
 * ISR — STAT alarm button (top-half)                                  [App 3]
 * ============================================================================
 * Correct pattern preserved from App 3: do the absolute minimum (bump a
 * counter, drive a scope-probe pin so the ISR window is visible on a logic
 * analyzer, give the semaphore, request a yield) and nothing else — no
 * logging, no mutex, no float math inside an ISR.
 * ============================================================================ */
static void IRAM_ATTR stat_button_isr(void *arg)
{
    int64_t now = esp_timer_get_time();
    if (now - last_stat_edge_us < DEBOUNCE_US) return;
    last_stat_edge_us = now;

    gpio_set_level(SCOPE_ISR_GPIO, 1);   /* scope-visible ISR window, dropped right below */

    isr_fire_count++;
    alarm_trigger_time_us = now;

    BaseType_t woken = pdFALSE;
    xSemaphoreGiveFromISR(stat_alarm_sem, &woken);

    BaseType_t woken2 = pdFALSE;
    vTaskNotifyGiveFromISR(ui_notify_handle, &woken2);
    if (woken2 == pdTRUE) woken = pdTRUE;

    gpio_set_level(SCOPE_ISR_GPIO, 0);

#if BREAK_ISR_SAFETY_RULE
    /* Deliberately violates the safety rule: no immediate context switch
     * request. The alarm task now waits for the next natural tick/
     * preemption point instead of running immediately. README Section 6
     * has the measured latency delta this produces. */
#else
    portYIELD_FROM_ISR(woken);
#endif
}

/* ---------- ISR — SIM button: inject a test arrhythmia burst (test aid) --- */
static void IRAM_ATTR sim_button_isr(void *arg)
{
    int64_t now = esp_timer_get_time();
    if (now - last_sim_edge_us < DEBOUNCE_US) return;
    last_sim_edge_us = now;
    anomaly_inject_until_us = now + 1000000;  /* 1 s burst, consumed by task_ecg_sample */
}

/* ============================================================================
 * TASK A — task_ecg_sample (producer)     prio 15   period 10 ms   [App 1/2/4]
 * NEVER SHED — this is the vitals-capture path.
 * ============================================================================ */
static void task_ecg_sample(void *arg)
{
    TickType_t last = xTaskGetTickCount();
    const TickType_t period = pdMS_TO_TICKS(10);
    int32_t y = 0x1000;
    const int32_t alpha = 6553;
    uint32_t sample_no = 0;

    for (;;) {
        int64_t dt;
        MEASURE_WCET(dt, wcet_ecg_us, {
            /* Pure-compute stand-in for an analog front-end sample + IIR
             * smoothing pass (no real ADC in the simulator) — same
             * technique App 4/5 used, deterministic and cheap. */
            bool inject = (esp_timer_get_time() < anomaly_inject_until_us);
            for (int i = 0; i < 32; i++) {
                int32_t in = i * 1103515245 + 12345;
                if (inject) in *= 7;   /* wider excursion during an injected burst */
                y += (int32_t)(((int64_t)alpha * (in - y)) >> 16);
            }
            sample_no++;

            uint32_t next_head = (ecg_ring_head + 1) % ECG_RING_DEPTH;
            if (next_head == ecg_ring_tail) {
                ecg_overrun_count++;   /* consumer can't keep up — counted, not silent */
            } else {
                ecg_ring[ecg_ring_head] = y;
                ecg_ring_head = next_head;
                xSemaphoreGive(sample_backlog_sem);
            }
            xEventGroupSetBits(cycle_evt_group, EV_SAMPLE_READY);
        });
        note_deadline(dt, 10, &deadline_miss_ecg);

        /* ~1 Hz vitals beacon derived from the 10 ms sample clock — same
         * "1 Hz reads as a heartbeat" reasoning App 1's README defended. */
        if ((sample_no % 100) == 0) {
            gpio_set_level(LED_VITALS_GPIO, !gpio_get_level(LED_VITALS_GPIO));
        }

        hb_ecg++;
        vTaskDelayUntil(&last, period);
    }
}

/* ============================================================================
 * TASK B — task_arrhy_detect (consumer, batch-drain)  prio 12  period 20 ms
 *                                                                   [App 2/4/5]
 * NEVER SHED — this is the detection path.
 * ============================================================================ */
static void task_arrhy_detect(void *arg)
{
    static int32_t hist[8];
    static int hist_i = 0;
    TickType_t last = xTaskGetTickCount();
    const TickType_t period = pdMS_TO_TICKS(20);

    for (;;) {
        int64_t dt;
        bool any_processed = false;
        int32_t last_bpm = 0;
        bool last_abnormal = false;

        MEASURE_WCET(dt, wcet_arrhy_us, {
            /* Drain everything the producer queued this cycle — up to the
             * full ring depth, so one detect cycle has a bounded worst case
             * even if the backlog is completely full. */
            for (int drained = 0; drained < ECG_RING_DEPTH; drained++) {
                if (xSemaphoreTake(sample_backlog_sem, 0) != pdTRUE) break;

                int32_t sample = ecg_ring[ecg_ring_tail];
                ecg_ring_tail = (ecg_ring_tail + 1) % ECG_RING_DEPTH;

                hist[hist_i] = sample;
                hist_i = (hist_i + 1) & 7;
                int32_t mean = 0;
                for (int i = 0; i < 8; i++) mean += hist[i];
                mean >>= 3;
                int32_t var = 0;
                for (int i = 0; i < 8; i++) { int32_t d = hist[i] - mean; var += d * d; }
                float std = sqrtf((float)var / 8.0f);

                last_abnormal = std > 6000.0f;
                last_bpm = 60 + (sample & 0x3F);
                any_processed = true;
            }
        });
        note_deadline(dt, 20, &deadline_miss_arrhy);

        if (any_processed) {
#if INDUCE_FAILURE
            patient_record.heart_rate_bpm  = last_bpm;
            patient_record.arrhythmia_flag = last_abnormal;
#else
            if (record_lock(pdMS_TO_TICKS(5))) {
                patient_record.heart_rate_bpm  = last_bpm;
                patient_record.arrhythmia_flag = last_abnormal;
                record_unlock();
            }
#endif
            if (last_abnormal) {
                /* Software-detected alarm: same alarm path the STAT button
                 * uses, tagged source=1 so the web/log can tell them apart. */
                sw_trigger_count++;
                alarm_trigger_time_us = esp_timer_get_time();
                xSemaphoreGive(stat_alarm_sem);
            }
        }

        xEventGroupSetBits(cycle_evt_group, EV_DETECT_DONE);
        hb_arrhy++;
        vTaskDelayUntil(&last, period);
    }
}

/* ============================================================================
 * TASK C — task_coordinator     prio 11     event-driven (~20 ms cadence) [App 5]
 * SHED at DEGRADED_1 and worse — pure observability, no functional role.
 * ============================================================================ */
static void task_coordinator(void *arg)
{
    const EventBits_t wait_mask = EV_SAMPLE_READY | EV_DETECT_DONE;
    for (;;) {
        if (system_mode >= MODE_DEGRADED_1) {
            /* Shed: stop actively rendezvousing, just idle. Leaving the bits
             * unconsumed is fine — xEventGroupSetBits is OR-additive and the
             * producer/detector don't block on this task ever clearing them. */
            vTaskDelay(pdMS_TO_TICKS(200));
            continue;
        }

        EventBits_t got = xEventGroupWaitBits(cycle_evt_group, wait_mask,
                                               pdTRUE, pdTRUE, pdMS_TO_TICKS(200));
        if ((got & wait_mask) == wait_mask) {
            hb_coord++;
        } else {
            coordinator_timeout_count++;   /* a full pipeline "beat" didn't complete in time */
        }
    }
}

/* ============================================================================
 * TASK D — task_alarm_isr (bottom-half)     prio 20 (highest)         [App 3/4]
 * NEVER SHED — this drives the physical patient-alarm output.
 * ============================================================================ */
static void task_alarm_isr(void *arg)
{
    for (;;) {
        xSemaphoreTake(stat_alarm_sem, portMAX_DELAY);

        int64_t t0 = esp_timer_get_time();
        int64_t lat = t0 - alarm_trigger_time_us;
        if (lat >= 0 && (uint64_t)lat > alarm_latency_max_us) alarm_latency_max_us = (uint64_t)lat;

        uint32_t this_alarm_no;
#if INDUCE_FAILURE
        patient_record.alarm_count++;
        patient_record.alarm_active = true;
        this_alarm_no = patient_record.alarm_count;
#else
        if (record_lock(pdMS_TO_TICKS(5))) {
            patient_record.alarm_count++;
            patient_record.alarm_active = true;
            this_alarm_no = patient_record.alarm_count;
            record_unlock();
        } else {
            this_alarm_no = 0;   /* couldn't confirm a count, but the LED still fires below */
        }
#endif

        gpio_set_level(LED_ALARM_GPIO, 1);   /* physical output — independent of any queue/lock downstream */
        ESP_LOGW(TAG, "[STAT ALARM] #%lu latency=%lld us (max %llu us)",
                 (unsigned long)this_alarm_no, (long long)lat, (unsigned long long)alarm_latency_max_us);

        /* Non-blocking: telemetry is sheddable, the alarm output above is not. */
        alarm_event_t evt = {
            .t_ms = (uint32_t)(t0 / 1000),
            .source = (esp_timer_get_time() - alarm_trigger_time_us < 2000) ? 0 : 1,
            .alarm_no = this_alarm_no,
        };
        if (xQueueSend(alarm_evt_q, &evt, 0) != pdTRUE) alarm_dispatch_drops++;

        vTaskDelay(pdMS_TO_TICKS(300));   /* audible/visual hold time */
        gpio_set_level(LED_ALARM_GPIO, 0);

#if !INDUCE_FAILURE
        if (record_lock(pdMS_TO_TICKS(5))) {
            patient_record.alarm_active = false;
            record_unlock();
        }
#else
        patient_record.alarm_active = false;
#endif
        hb_alarm++;
    }
}

/* ============================================================================
 * TASK D2 — task_ui_notify (direct-notification bottom-half)  prio 13  [App 3/5]
 * Wakes via ulTaskNotifyTake from the STAT ISR only. Cheap and non-safety-
 * critical: it just timestamps "the STAT button was just pressed" for the
 * web dashboard and records the notification-path latency for comparison
 * against stat_alarm_sem's semaphore-path latency (README Section 4).
 * ============================================================================ */
static void task_ui_notify(void *arg)
{
    for (;;) {
        uint32_t n = ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
        if (n == 0) continue;

        int64_t wake = esp_timer_get_time();
        int64_t lat = wake - alarm_trigger_time_us;
        if (lat >= 0 && (uint64_t)lat > notif_latency_max_us) notif_latency_max_us = (uint64_t)lat;
        last_stat_ui_refresh_ms = (uint32_t)(wake / 1000);
        hb_ui++;
    }
}

/* ============================================================================
 * TASK E — task_alarm_dispatch     prio 8     period 40 ms            [App 2/5]
 * SHED at DEGRADED_1. Formats/queues alarm telemetry only — never gates the
 * physical alarm output, which already happened in task_alarm_isr.
 * ============================================================================ */
static void task_alarm_dispatch(void *arg)
{
    static uint8_t pkt[512];
    TickType_t last = xTaskGetTickCount();
    const TickType_t period = pdMS_TO_TICKS(40);

    for (;;) {
        if (system_mode >= MODE_DEGRADED_1) {
            vTaskDelayUntil(&last, period);
            continue;
        }

        int64_t dt;
        MEASURE_WCET(dt, wcet_dispatch_us, {
            alarm_event_t evt;
            while (xQueueReceive(alarm_evt_q, &evt, 0) == pdTRUE) {
                /* Stand-in "packetize for telemetry" work, same CRC-style
                 * busy-work shape App 2/3's background load used, sized to
                 * fit comfortably inside the 40 ms period. */
                uint32_t crc = 0xFFFFFFFFu ^ evt.alarm_no;
                for (int n = 0; n < 512; n++) {
                    pkt[n] = (uint8_t)((evt.t_ms + n) & 0xFF);
                    crc ^= pkt[n];
                    for (int b = 0; b < 8; b++)
                        crc = (crc >> 1) ^ (0xEDB88320u & (-(int32_t)(crc & 1)));
                }
                ESP_LOGI(TAG, "[dispatch] alarm #%lu src=%u crc=%08lx",
                         (unsigned long)evt.alarm_no, evt.source, (unsigned long)crc);
            }
        });
        note_deadline(dt, 40, &deadline_miss_dispatch);

        hb_dispatch++;
        vTaskDelayUntil(&last, period);
    }
}

/* ============================================================================
 * TASK F — task_degr_manager     prio 6     period 100 ms              [NEW]
 * NEVER SHED — this is what runs the degradation ladder itself.
 * ============================================================================ */
static void task_degr_manager(void *arg)
{
    const TickType_t period = pdMS_TO_TICKS(100);

    uint32_t prev_overrun = 0, prev_drops = 0, prev_hb_ecg = 0;
    int bad_streak = 0, good_streak = 0;
    bool fault_blink_state = false;

    /* Startup grace period. Every periodic task here runs its first loop
     * body immediately on creation (no initial delay) -- fine for most of
     * them, but WRONG for a watchdog: without this, the very first check
     * below would run at essentially t=0, before task_ecg_sample has had a
     * real 100 ms window to accumulate heartbeats, and a bare-startup
     * hb_ecg delta of 0-1 looks identical to a genuine stall. A supervisor
     * must not declare its supervisee dead before the supervisee has had a
     * chance to start. */
    vTaskDelay(pdMS_TO_TICKS(150));
    prev_hb_ecg = hb_ecg;   /* baseline captured AFTER the grace period */
    vTaskDelay(pdMS_TO_TICKS(100));   /* let one real period elapse before the FIRST delta check */

    TickType_t last = xTaskGetTickCount();
    for (;;) {
        uint32_t overrun_delta = ecg_overrun_count - prev_overrun;
        uint32_t drops_delta   = alarm_dispatch_drops - prev_drops;
        uint32_t ecg_delta     = hb_ecg - prev_hb_ecg;      /* expect ~10 per 100 ms */
        prev_overrun = ecg_overrun_count;
        prev_drops   = alarm_dispatch_drops;
        prev_hb_ecg  = hb_ecg;

        /* --- Immediate, no-hysteresis escalation: vitals or lock integrity --- */
        bool severe = (ecg_delta < 5) || (mutex_timeout_count > 0);
        if (severe) {
            if (system_mode != MODE_SAFE_MINIMAL) {
                system_mode = MODE_SAFE_MINIMAL;
                mode_transition_count++;
                ESP_LOGE(TAG, "[degradation] -> SAFE_MINIMAL (ecg_delta=%lu mutex_timeouts=%lu)",
                         (unsigned long)ecg_delta, (unsigned long)mutex_timeout_count);
            }
            bad_streak = 3; good_streak = 0;   /* require a full recovery run before stepping down */
        } else {
            bool bad = (overrun_delta > 0) || (drops_delta > 2) || (coordinator_timeout_count > 0);
            coordinator_timeout_count = 0;   /* consume this check's signal */

            if (bad) {
                bad_streak++;
                good_streak = 0;
            } else {
                good_streak++;
                bad_streak = 0;
            }

            /* Escalate fast (3 consecutive bad checks = 300 ms). */
            if (bad_streak >= 3 && system_mode < MODE_DEGRADED_2) {
                system_mode = (system_mode == MODE_NORMAL) ? MODE_DEGRADED_1 : MODE_DEGRADED_2;
                mode_transition_count++;
                ESP_LOGW(TAG, "[degradation] -> %s (overrun_delta=%lu drop_delta=%lu)",
                         mode_name(system_mode), (unsigned long)overrun_delta, (unsigned long)drops_delta);
                bad_streak = 0;
            }
            /* Recover slowly (10 consecutive clean checks = 1 s clean). */
            if (good_streak >= 10 && system_mode > MODE_NORMAL) {
                system_mode = (system_mode == MODE_SAFE_MINIMAL) ? MODE_DEGRADED_2
                             : (system_mode == MODE_DEGRADED_2)  ? MODE_DEGRADED_1
                                                                  : MODE_NORMAL;
                mode_transition_count++;
                ESP_LOGI(TAG, "[degradation] recovering -> %s", mode_name(system_mode));
                good_streak = 0;
            }
        }

        if (record_lock(pdMS_TO_TICKS(5))) {
            patient_record.mode = system_mode;
            record_unlock();
        }

        /* FAULT LED: off in NORMAL, steady in DEGRADED_1/2, fast-blink+latched in SAFE_MINIMAL. */
        switch (system_mode) {
            case MODE_NORMAL:       gpio_set_level(LED_FAULT_GPIO, 0); break;
            case MODE_DEGRADED_1:
            case MODE_DEGRADED_2:   gpio_set_level(LED_FAULT_GPIO, 1); break;
            case MODE_SAFE_MINIMAL:
                fault_blink_state = !fault_blink_state;
                gpio_set_level(LED_FAULT_GPIO, fault_blink_state);
                break;
        }

        hb_degr++;
        vTaskDelayUntil(&last, period);
    }
}

/* ============================================================================
 * TASK G — task_data_log     prio 3     period 200 ms                [App 2/4]
 * SHED at DEGRADED_2 and worse. First-in-line at DEGRADED_1 too if you count
 * that its own read still incurs mutex contention risk — kept until
 * DEGRADED_2 here because it's cheap and its evidence is genuinely useful.
 * ============================================================================ */
static void task_data_log(void *arg)
{
    TickType_t last = xTaskGetTickCount();
    const TickType_t period = pdMS_TO_TICKS(200);

    for (;;) {
        if (system_mode >= MODE_DEGRADED_2) {
            vTaskDelayUntil(&last, period);
            continue;
        }

        int64_t dt;
        patient_record_t snapshot;
        MEASURE_WCET(dt, wcet_log_us, {
#if INDUCE_FAILURE
            snapshot = patient_record;   /* torn read possible — that's the point */
#else
            if (record_lock(pdMS_TO_TICKS(5))) {
                snapshot = patient_record;
                record_unlock();
            }
#endif
        });
        note_deadline(dt, 200, &deadline_miss_log);

        ESP_LOGI(TAG,
            "[Bed 4-A] mode=%s HR=%ld arrhy=%d alarms=%lu active=%d | "
            "ring_ovr=%lu q_drop=%lu mtx_to=%lu | "
            "hb: ecg=%lu arrhy=%lu disp=%lu degr=%lu log=%lu alarm=%lu coord=%lu ui=%lu | "
            "wcet_us: ecg=%llu arrhy=%llu disp=%llu log=%llu | latency_us: sem=%llu notif=%llu | "
            "miss: ecg=%lu arrhy=%lu disp=%lu log=%lu",
            mode_name(snapshot.mode), (long)snapshot.heart_rate_bpm, snapshot.arrhythmia_flag,
            (unsigned long)snapshot.alarm_count, snapshot.alarm_active,
            (unsigned long)ecg_overrun_count, (unsigned long)alarm_dispatch_drops,
            (unsigned long)mutex_timeout_count,
            (unsigned long)hb_ecg, (unsigned long)hb_arrhy, (unsigned long)hb_dispatch,
            (unsigned long)hb_degr, (unsigned long)hb_log, (unsigned long)hb_alarm, (unsigned long)hb_coord,
            (unsigned long)hb_ui,
            (unsigned long long)wcet_ecg_us, (unsigned long long)wcet_arrhy_us,
            (unsigned long long)wcet_dispatch_us, (unsigned long long)wcet_log_us,
            (unsigned long long)alarm_latency_max_us, (unsigned long long)notif_latency_max_us,
            (unsigned long)deadline_miss_ecg, (unsigned long)deadline_miss_arrhy,
            (unsigned long)deadline_miss_dispatch, (unsigned long)deadline_miss_log);

        hb_log++;
        vTaskDelayUntil(&last, period);
    }
}

/* ============================================================================
 * OPTIONAL — OVERLOAD_DEMO: saturates Core 1 so the degradation ladder can
 * be shown stepping down LIVE in Wokwi without waiting for a real fault.
 * Priority 7 sits between dispatch(8) and degr_manager(6) on purpose: it
 * competes with sheddable work but never outranks the never-shed tasks.
 * ============================================================================ */
#if OVERLOAD_DEMO
static void task_overload_hog(void *arg)
{
    for (;;) {
        volatile uint32_t x = 0;
        for (int i = 0; i < 400000; i++) x += i * 2654435761u;
        vTaskDelay(pdMS_TO_TICKS(5));
    }
}
#endif

/* ============================================================================
 * OPTIONAL — PRIORITY_INVERSION_DEMO: isolated H/M/L demonstration.   [App 4]
 * Priorities (19/9/1) are deliberately offset from the production set
 * (20/12/6/etc.) so this demo never ties with a real task's priority —
 * a genuine tie would itself be a scheduling hazard, which is not the point
 * being demonstrated here.
 * ============================================================================ */
#if PRIORITY_INVERSION_DEMO
static SemaphoreHandle_t pi_lock;
static volatile uint32_t pi_shared_counter = 0;

static void task_pi_H(void *arg)
{
    for (;;) {
        int64_t t0 = esp_timer_get_time();
        xSemaphoreTake(pi_lock, portMAX_DELAY);
        int64_t waited = esp_timer_get_time() - t0;
        pi_shared_counter++;
        xSemaphoreGive(pi_lock);
        ESP_LOGW(TAG, "[PI-H] acquired after %lld us wait (counter=%lu)", waited, (unsigned long)pi_shared_counter);
        vTaskDelay(pdMS_TO_TICKS(50));
    }
}
static void task_pi_M(void *arg)
{
    for (;;) {
        volatile uint32_t x = 0;
        for (int i = 0; i < 200000; i++) x += i * 3;
        vTaskDelay(pdMS_TO_TICKS(20));
    }
}
static void task_pi_L(void *arg)
{
    for (;;) {
        xSemaphoreTake(pi_lock, portMAX_DELAY);
        ESP_LOGI(TAG, "[PI-L] holding lock...");
        vTaskDelay(pdMS_TO_TICKS(80));
        xSemaphoreGive(pi_lock);
        vTaskDelay(pdMS_TO_TICKS(30));
    }
}
#endif /* PRIORITY_INVERSION_DEMO */

/* ============================================================================
 * TASK H — task_serial_monitor (Core 0)     prio 4     period 1000 ms  [App 1/5]
 * Always runs regardless of USE_WEBSERVER — "the serial log alone is
 * sufficient proof of life," same call made in the A1 README.
 * ============================================================================ */
static void task_serial_monitor(void *arg)
{
    TickType_t last = xTaskGetTickCount();
    const TickType_t period = pdMS_TO_TICKS(1000);
    for (;;) {
        printf("=== BED 4-A === mode=%s hb[ecg=%lu arrhy=%lu disp=%lu degr=%lu log=%lu alarm=%lu coord=%lu] "
               "isr=%lu sw=%lu ring_ovr=%lu q_drop=%lu mtx_to=%lu transitions=%lu\n",
               mode_name(system_mode),
               (unsigned long)hb_ecg, (unsigned long)hb_arrhy, (unsigned long)hb_dispatch,
               (unsigned long)hb_degr, (unsigned long)hb_log, (unsigned long)hb_alarm, (unsigned long)hb_coord,
               (unsigned long)isr_fire_count, (unsigned long)sw_trigger_count,
               (unsigned long)ecg_overrun_count, (unsigned long)alarm_dispatch_drops,
               (unsigned long)mutex_timeout_count, (unsigned long)mode_transition_count);
        vTaskDelayUntil(&last, period);
    }
}

/* ============================================================================
 * TASK I — task_web_monitor (Core 0)                                   [App 1]
 * ============================================================================ */
#if USE_WEBSERVER
static char http_buf[3072];

static esp_err_t handle_state(httpd_req_t *req)
{
    patient_record_t snap;
    if (record_lock(pdMS_TO_TICKS(5))) { snap = patient_record; record_unlock(); }
    int n = snprintf(http_buf, sizeof(http_buf),
        "{\"mode\":\"%s\",\"hr\":%ld,\"arrhythmia\":%s,\"alarm_active\":%s,\"alarm_count\":%lu,"
        "\"ring_overruns\":%lu,\"dispatch_drops\":%lu,\"mutex_timeouts\":%lu,"
        "\"mode_transitions\":%lu,"
        "\"hb\":{\"ecg\":%lu,\"arrhy\":%lu,\"dispatch\":%lu,\"degr\":%lu,\"log\":%lu,\"alarm\":%lu,\"coord\":%lu,\"ui\":%lu},"
        "\"wcet_us\":{\"ecg\":%llu,\"arrhy\":%llu,\"dispatch\":%llu,\"log\":%llu,\"alarm_latency\":%llu,\"notif_latency\":%llu},"
        "\"deadline_miss\":{\"ecg\":%lu,\"arrhy\":%lu,\"dispatch\":%lu,\"log\":%lu}}",
        mode_name(snap.mode), (long)snap.heart_rate_bpm,
        snap.arrhythmia_flag ? "true" : "false", snap.alarm_active ? "true" : "false",
        (unsigned long)snap.alarm_count,
        (unsigned long)ecg_overrun_count, (unsigned long)alarm_dispatch_drops, (unsigned long)mutex_timeout_count,
        (unsigned long)mode_transition_count,
        (unsigned long)hb_ecg, (unsigned long)hb_arrhy, (unsigned long)hb_dispatch,
        (unsigned long)hb_degr, (unsigned long)hb_log, (unsigned long)hb_alarm, (unsigned long)hb_coord,
        (unsigned long)hb_ui,
        (unsigned long long)wcet_ecg_us, (unsigned long long)wcet_arrhy_us,
        (unsigned long long)wcet_dispatch_us, (unsigned long long)wcet_log_us,
        (unsigned long long)alarm_latency_max_us, (unsigned long long)notif_latency_max_us,
        (unsigned long)deadline_miss_ecg, (unsigned long)deadline_miss_arrhy,
        (unsigned long)deadline_miss_dispatch, (unsigned long)deadline_miss_log);
    httpd_resp_set_type(req, "application/json");
    httpd_resp_set_hdr(req, "Cache-Control", "no-store");
    httpd_resp_send(req, http_buf, n);
    return ESP_OK;
}

static esp_err_t handle_root(httpd_req_t *req)
{
    static const char html[] =
        "<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\">"
        "<title>Bed 4-A ECG Monitor</title><style>"
        "body{font-family:-apple-system,sans-serif;background:#FAFAF5;color:#1A1A1A;padding:2rem;max-width:640px;margin:auto}"
        "h1{color:#A61C1C;border-bottom:3px solid #E63946;display:inline-block;padding-bottom:4px}"
        ".hr{font-size:3em;font-weight:700;margin:.5rem 0}"
        ".mode{display:inline-block;padding:.3em .8em;border-radius:6px;font-weight:700;color:#fff}"
        ".m-NORMAL{background:#1B6A2E}.m-DEGRADED_1{background:#B8860B}"
        ".m-DEGRADED_2{background:#C1440E}.m-SAFE_MINIMAL{background:#B81829}"
        ".alarm{font-weight:700}.alarm.on{color:#B81829}.alarm.off{color:#555}"
        "table{border-collapse:collapse;margin-top:1em;width:100%}"
        "td{padding:3px 10px;border-bottom:1px solid #eee;font-variant-numeric:tabular-nums}"
        "td.k{color:#555}</style></head><body>"
        "<h1>Bed 4-A &mdash; ECG Bedside Monitor</h1>"
        "<p>System mode: <span id=\"mode\" class=\"mode\">--</span></p>"
        "<div class=\"hr\"><span id=\"bpm\">--</span> <small>bpm</small></div>"
        "<p>Alarm: <span id=\"alarm\" class=\"alarm off\">--</span> "
        "(<span id=\"acount\">0</span> total)</p>"
        "<table>"
        "<tr><td class=\"k\">Ring overruns</td><td id=\"ovr\">0</td></tr>"
        "<tr><td class=\"k\">Telemetry drops</td><td id=\"drp\">0</td></tr>"
        "<tr><td class=\"k\">Mutex timeouts</td><td id=\"mto\">0</td></tr>"
        "<tr><td class=\"k\">Mode transitions</td><td id=\"trn\">0</td></tr>"
        "<tr><td class=\"k\">Alarm latency (max)</td><td id=\"lat\">0</td></tr>"
        "<tr><td class=\"k\">WCET ecg/arrhy/disp/log (us)</td><td id=\"wcet\">--</td></tr>"
        "<tr><td class=\"k\">Deadline misses e/a/d/l</td><td id=\"miss\">--</td></tr>"
        "<tr><td class=\"k\">Heartbeats</td><td id=\"hbs\">--</td></tr>"
        "</table>"
        "<p style=\"color:#888;font-size:.85em\">Polling /state at 4 Hz. Coursework simulation &mdash; not a certified medical device.</p>"
        "<script>"
        "async function poll(){try{"
        "const r=await fetch('/state',{cache:'no-store'});const s=await r.json();"
        "const m=document.getElementById('mode');m.textContent=s.mode;m.className='mode m-'+s.mode;"
        "document.getElementById('bpm').textContent=s.hr;"
        "const a=document.getElementById('alarm');a.textContent=s.alarm_active?'ACTIVE':'nominal';"
        "a.className='alarm '+(s.alarm_active?'on':'off');"
        "document.getElementById('acount').textContent=s.alarm_count;"
        "document.getElementById('ovr').textContent=s.ring_overruns;"
        "document.getElementById('drp').textContent=s.dispatch_drops;"
        "document.getElementById('mto').textContent=s.mutex_timeouts;"
        "document.getElementById('trn').textContent=s.mode_transitions;"
        "document.getElementById('lat').textContent=s.wcet_us.alarm_latency+' us';"
        "document.getElementById('wcet').textContent=s.wcet_us.ecg+' / '+s.wcet_us.arrhy+' / '+s.wcet_us.dispatch+' / '+s.wcet_us.log;"
        "document.getElementById('miss').textContent=s.deadline_miss.ecg+' / '+s.deadline_miss.arrhy+' / '+s.deadline_miss.dispatch+' / '+s.deadline_miss.log;"
        "document.getElementById('hbs').textContent=JSON.stringify(s.hb);"
        "}catch(e){}}"
        "setInterval(poll,250);poll();"
        "</script></body></html>";
    httpd_resp_set_type(req, "text/html");
    httpd_resp_send(req, html, HTTPD_RESP_USE_STRLEN);
    return ESP_OK;
}

static void start_webserver(void)
{
    httpd_config_t cfg = HTTPD_DEFAULT_CONFIG();
    cfg.server_port = 80;
    cfg.core_id = 0;
    cfg.task_priority = 5;
    cfg.stack_size = 8192;

    httpd_handle_t server = NULL;
    if (httpd_start(&server, &cfg) == ESP_OK) {
        httpd_uri_t root  = { .uri = "/",      .method = HTTP_GET, .handler = handle_root  };
        httpd_uri_t state = { .uri = "/state", .method = HTTP_GET, .handler = handle_state };
        httpd_register_uri_handler(server, &root);
        httpd_register_uri_handler(server, &state);
        ESP_LOGI(TAG, "web dashboard listening on port 80");
    } else {
        ESP_LOGE(TAG, "httpd_start failed");
    }
}

static void wifi_event_handler(void *arg, esp_event_base_t base, int32_t id, void *data)
{
    if (base == WIFI_EVENT && id == WIFI_EVENT_STA_START) {
        esp_wifi_connect();
    } else if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) {
        ESP_LOGW(TAG, "Wi-Fi disconnected; reconnecting...");
        esp_wifi_connect();
    } else if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t *event = (ip_event_got_ip_t *)data;
        ESP_LOGI(TAG, "Got IP: " IPSTR, IP2STR(&event->ip_info.ip));
        start_webserver();
    }
}

static void wifi_init_sta(void)
{
    esp_err_t nvs_ret = nvs_flash_init();
    if (nvs_ret == ESP_ERR_NVS_NO_FREE_PAGES || nvs_ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        nvs_ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(nvs_ret);
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();

    wifi_init_config_t init_cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&init_cfg));
    ESP_ERROR_CHECK(esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, &wifi_event_handler, NULL));
    ESP_ERROR_CHECK(esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP, &wifi_event_handler, NULL));

    wifi_config_t wifi_cfg = {
        .sta = { .ssid = "Wokwi-GUEST", .password = "", .threshold.authmode = WIFI_AUTH_OPEN },
    };
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifi_cfg));
    ESP_ERROR_CHECK(esp_wifi_start());
}

static void task_web_monitor(void *arg)
{
    wifi_init_sta();
    for (;;) vTaskDelay(pdMS_TO_TICKS(1000));
}
#endif /* USE_WEBSERVER */

/* ============================================================================
 * app_main
 * ============================================================================ */
void app_main(void)
{
    esp_log_level_set(TAG, ESP_LOG_INFO);
    ESP_LOGI(TAG, "==== Bed 4-A Capstone starting ====");
    ESP_LOGI(TAG, "USE_WEBSERVER=%d BREAK_ISR_SAFETY_RULE=%d INDUCE_FAILURE=%d "
                  "PRIORITY_INVERSION_DEMO=%d(LOCK=%s) OVERLOAD_DEMO=%d",
             USE_WEBSERVER, BREAK_ISR_SAFETY_RULE, INDUCE_FAILURE, PRIORITY_INVERSION_DEMO,
             (LOCK_TYPE == LOCK_MUTEX) ? "MUTEX(PI-ON)" : "BINARY(PI-OFF)", OVERLOAD_DEMO);

    memset(&patient_record, 0, sizeof(patient_record));
    record_mutex       = xSemaphoreCreateMutex();
    sample_backlog_sem = xSemaphoreCreateCounting(ECG_RING_DEPTH, 0);
    stat_alarm_sem      = xSemaphoreCreateBinary();
    alarm_evt_q         = xQueueCreate(ALARM_Q_DEPTH, sizeof(alarm_event_t));
    cycle_evt_group     = xEventGroupCreate();

    /* Configure LED/button GPIOs now, but DO NOT install/enable the button
     * ISRs yet — ui_notify_handle must be populated first. Creating tasks
     * before enabling interrupts removes the boot-time race where a very
     * early button edge could call vTaskNotifyGiveFromISR on a still-NULL
     * handle (the same class of bug App 5's README called out explicitly). */
    gpio_config_t out_cfg = {
        .pin_bit_mask = (1ULL << LED_ALARM_GPIO) | (1ULL << LED_VITALS_GPIO) |
                         (1ULL << LED_FAULT_GPIO) | (1ULL << SCOPE_ISR_GPIO),
        .mode = GPIO_MODE_OUTPUT,
    };
    gpio_config(&out_cfg);
    gpio_set_level(LED_ALARM_GPIO, 0);
    gpio_set_level(LED_VITALS_GPIO, 0);
    gpio_set_level(LED_FAULT_GPIO, 0);
    gpio_set_level(SCOPE_ISR_GPIO, 0);

    /* Core 1 — real-time plane. Priorities are rate-monotonic by period,
     * with the two never-shed, event-driven safety tasks (alarm=20, and the
     * hard-periodic vitals producer=15) anchoring the top. See README.md
     * Section 4 for the full schedulability argument. */
    xTaskCreatePinnedToCore(task_alarm_isr,      "alarm_isr",  4096, NULL, 20, NULL, 1);
    xTaskCreatePinnedToCore(task_ecg_sample,     "ecg_sample", 4096, NULL, 15, NULL, 1);
    xTaskCreatePinnedToCore(task_ui_notify,      "ui_notify",  3072, NULL, 13, &ui_notify_handle, 1);
    xTaskCreatePinnedToCore(task_arrhy_detect,   "arrhy_det",  4096, NULL, 12, NULL, 1);
    xTaskCreatePinnedToCore(task_coordinator,    "coord",      3072, NULL, 11, NULL, 1);
    xTaskCreatePinnedToCore(task_alarm_dispatch, "alarm_disp", 4096, NULL,  8, NULL, 1);
    xTaskCreatePinnedToCore(task_degr_manager,   "degr_mgr",   3072, NULL,  6, NULL, 1);
    xTaskCreatePinnedToCore(task_data_log,       "data_log",   4096, NULL,  3, NULL, 1);

#if OVERLOAD_DEMO
    xTaskCreatePinnedToCore(task_overload_hog, "overload_hog", 2048, NULL, 7, NULL, 1);
#endif

#if PRIORITY_INVERSION_DEMO
    pi_lock = (LOCK_TYPE == LOCK_MUTEX) ? xSemaphoreCreateMutex() : xSemaphoreCreateBinary();
    if (LOCK_TYPE == LOCK_BINARY) xSemaphoreGive(pi_lock);
    xTaskCreatePinnedToCore(task_pi_H, "pi_H", 2048, NULL, 19, NULL, 1);
    xTaskCreatePinnedToCore(task_pi_M, "pi_M", 2048, NULL,  9, NULL, 1);
    xTaskCreatePinnedToCore(task_pi_L, "pi_L", 2048, NULL,  1, NULL, 1);
#endif

    /* Core 0 — networking / observability plane. */
    xTaskCreatePinnedToCore(task_serial_monitor, "serial_mon", 3072, NULL, 4, NULL, 0);
#if USE_WEBSERVER
    xTaskCreatePinnedToCore(task_web_monitor, "web_mon", 4096, NULL, 4, NULL, 0);
#endif

    /* NOW it is safe to install and enable the button ISRs — every task
     * they can notify or signal already exists. */
    gpio_config_t btn_cfg = {
        .pin_bit_mask = (1ULL << BTN_STAT_GPIO) | (1ULL << BTN_SIM_GPIO),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .intr_type = GPIO_INTR_NEGEDGE,
    };
    gpio_config(&btn_cfg);
    gpio_install_isr_service(0);
    gpio_isr_handler_add(BTN_STAT_GPIO, stat_button_isr, NULL);
    gpio_isr_handler_add(BTN_SIM_GPIO, sim_button_isr, NULL);

    ESP_LOGI(TAG, "System operational. STAT=GPIO%d  SIM=GPIO%d  ALARM_LED=GPIO%d  VITALS_LED=GPIO%d  FAULT_LED=GPIO%d",
             BTN_STAT_GPIO, BTN_SIM_GPIO, LED_ALARM_GPIO, LED_VITALS_GPIO, LED_FAULT_GPIO);
}
